// triad_engine.c — RAFAELIA TRIAD LAB (C low-level, Termux-friendly)
// Build:  cc -O2 -std=c11 triad_engine.c -lm -o triad
// Run:    ./triad --steps 300 --seed 42 --out out
//
// Triad: Toroid->c_n ; Mandelbrot z^2 + c ;
//        Bhaskara Δ = 1 - 4c ; 9->1 digital root ;
//        Fibonacci-Rafael FR ; J_n = stable + peak + (dr9(FR)==gate)
//
// Outputs:
//   out/triad_trace.csv
//   out/triad_report.json

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#include <sys/stat.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct { double re, im; } cplx;

static inline cplx c_add(cplx a, cplx b){ return (cplx){a.re+b.re, a.im+b.im}; }
static inline cplx c_sub(cplx a, cplx b){ return (cplx){a.re-b.re, a.im-b.im}; }
static inline cplx c_mul(cplx a, cplx b){
    return (cplx){a.re*b.re - a.im*b.im, a.re*b.im + a.im*b.re};
}
static inline double c_abs(cplx a){ return hypot(a.re, a.im); }

// principal sqrt for complex (stable)
static cplx c_sqrt(cplx z){
    double r = c_abs(z);
    if (r == 0.0) return (cplx){0.0, 0.0};
    double a = z.re, b = z.im;
    double t = sqrt((r + a)/2.0);
    double u = sqrt((r - a)/2.0);
    if (b < 0) u = -u;
    return (cplx){t, u};
}

// digital root 1..9; 0 -> 9
static int dr9_long(long long x){
    if (x < 0) x = -x;
    if (x == 0) return 9;
    int r = (int)(x % 9LL);
    return (r == 0) ? 9 : r;
}

// safe floor(|x|) into long long (clamped)
static long long safe_floor_ll(double x){
    double ax = fabs(x);
    if (!isfinite(ax)) return (long long)9e18;
    if (ax > 9e18) ax = 9e18;
    return (long long)floor(ax);
}

// Fibonacci-Rafael sequence: F1=2, F2=4, F_n = F_{n-1} + F_{n-2} - 1
// returns array size (n+1), with idx 0 placeholder
static long long* fr_build(int n){
    if (n < 0) n = 0;
    long long* f = (long long*)calloc((size_t)(n+1), sizeof(long long));
    if (!f) return NULL;
    if (n >= 1) f[1] = 2;
    if (n >= 2) f[2] = 4;
    for (int i=3;i<=n;i++){
        // beware overflow: clamp
        long long a = f[i-1], b = f[i-2];
        long long v;
        if (a > (LLONG_MAX - b + 1)) v = LLONG_MAX;
        else v = a + b - 1;
        f[i] = v;
    }
    return f;
}

static long long fr_rev_step(long long Fn, long long Fnm1){
    // reverse FR: F_{n-2} = F_n - F_{n-1} + 1
    return Fn - Fnm1 + 1;
}

typedef struct {
    int steps;
    int seed;
    double R, r;
    double alpha, beta;
    double kappa;
    double z0_re, z0_im;
    double lam;
    double z_cap;
} Params;

static int mkdir_p(const char* path){
    // simplistic mkdir -p for one level
    // If user passes "out" it's fine; for "a/b" ensure "a" exists
    char tmp[512];
    size_t n = strlen(path);
    if (n >= sizeof(tmp)) return -1;
    strcpy(tmp, path);

    for (size_t i=1;i<n;i++){
        if (tmp[i] == '/'){
            tmp[i] = '\0';
            mkdir(tmp, 0700);
            tmp[i] = '/';
        }
    }
    if (mkdir(tmp, 0700) != 0){
        if (errno != EEXIST) return -1;
    }
    return 0;
}

static cplx torus_c(double u, double v, const Params* p){
    double s = (p->R + p->r * cos(v));
    double x = s * cos(u);
    double y = s * sin(u);
    return (cplx){ p->kappa * x, p->kappa * y };
}

static cplx bhaskara_delta(cplx c){
    // Δ = 1 - 4c
    return (cplx){ 1.0 - 4.0*c.re, 0.0 - 4.0*c.im };
}

static void fixpoints_from_c(cplx c, cplx* z1, cplx* z2, cplx* D){
    *D = bhaskara_delta(c);
    cplx s = c_sqrt(*D);
    // (1 ± sqrtΔ)/2
    *z1 = (cplx){ (1.0 + s.re)/2.0, (0.0 + s.im)/2.0 };
    *z2 = (cplx){ (1.0 - s.re)/2.0, (0.0 - s.im)/2.0 };
}

static int stable_fixpoint(cplx zfp){
    // stable if |2z| < 1
    return (2.0*c_abs(zfp) < 1.0) ? 1 : 0;
}

static void write_report_json(const char* path,
                              const Params* p,
                              int stable_hits,
                              int escaped_ct,
                              const int gate_hist[10],
                              const int J_hist[4],
                              int last_gate,
                              int last_J,
                              long long last_FR){
    FILE* f = fopen(path, "wb");
    if (!f) return;
    fprintf(f, "{\n");
    fprintf(f, "  \"params\": {\n");
    fprintf(f, "    \"steps\": %d,\n", p->steps);
    fprintf(f, "    \"seed\": %d,\n", p->seed);
    fprintf(f, "    \"R\": %.12g,\n", p->R);
    fprintf(f, "    \"r\": %.12g,\n", p->r);
    fprintf(f, "    \"alpha\": %.12g,\n", p->alpha);
    fprintf(f, "    \"beta\": %.12g,\n", p->beta);
    fprintf(f, "    \"kappa\": %.12g,\n", p->kappa);
    fprintf(f, "    \"lam\": %.12g,\n", p->lam);
    fprintf(f, "    \"z_cap\": %.12g\n", p->z_cap);
    fprintf(f, "  },\n");
    fprintf(f, "  \"stable_hits\": %d,\n", stable_hits);
    fprintf(f, "  \"escaped_ct\": %d,\n", escaped_ct);

    fprintf(f, "  \"gate_hist_1to9\": {");
    for (int i=1;i<=9;i++){
        fprintf(f, "%s\"%d\": %d", (i==1?"":", "), i, gate_hist[i]);
    }
    fprintf(f, "},\n");

    fprintf(f, "  \"J_hist_0to3\": {");
    for (int i=0;i<=3;i++){
        fprintf(f, "%s\"%d\": %d", (i==0?"":", "), i, J_hist[i]);
    }
    fprintf(f, "},\n");

    fprintf(f, "  \"J_peaks\": [3,4,8],\n");
    fprintf(f, "  \"last\": {\"gate\": %d, \"J_n\": %d, \"FR\": %lld},\n", last_gate, last_J, last_FR);
    fprintf(f, "  \"notes\": {\n");
    fprintf(f, "    \"triad\": \"Toroide->c_n ; Mandelbrot z^2+c ; Bhaskara Δ=1-4c ; 9->1=dr(|Δ|) ; FR reverse\"\n");
    fprintf(f, "  }\n");
    fprintf(f, "}\n");
    fclose(f);
}

static void usage(){
    fprintf(stderr, "triad --steps N --seed S --out DIR [--R x --r y --alpha a --beta b --kappa k --lam L --zcap Z]\n");
}

int main(int argc, char** argv){
    Params p;
    p.steps = 300;
    p.seed  = 42;
    p.R = 2.0;
    p.r = 0.7;
    p.alpha = M_PI/7.0;
    p.beta  = M_PI/9.0;
    p.kappa = 0.22;
    p.z0_re = 0.0;
    p.z0_im = 0.0;
    p.lam   = 1000.0;
    p.z_cap = 1e6;

    const char* outdir = "out";

    for (int i=1;i<argc;i++){
        if (!strcmp(argv[i],"--steps") && i+1<argc) p.steps = atoi(argv[++i]);
        else if (!strcmp(argv[i],"--seed") && i+1<argc) p.seed = atoi(argv[++i]);
        else if (!strcmp(argv[i],"--out") && i+1<argc) outdir = argv[++i];
        else if (!strcmp(argv[i],"--R") && i+1<argc) p.R = atof(argv[++i]);
        else if (!strcmp(argv[i],"--r") && i+1<argc) p.r = atof(argv[++i]);
        else if (!strcmp(argv[i],"--alpha") && i+1<argc) p.alpha = atof(argv[++i]);
        else if (!strcmp(argv[i],"--beta") && i+1<argc) p.beta = atof(argv[++i]);
        else if (!strcmp(argv[i],"--kappa") && i+1<argc) p.kappa = atof(argv[++i]);
        else if (!strcmp(argv[i],"--lam") && i+1<argc) p.lam = atof(argv[++i]);
        else if (!strcmp(argv[i],"--zcap") && i+1<argc) p.z_cap = atof(argv[++i]);
        else { usage(); return 2; }
    }

    if (p.steps <= 0) p.steps = 1;
    if (mkdir_p(outdir) != 0){
        fprintf(stderr, "FAIL mkdir_p(%s)\n", outdir);
        return 2;
    }

    char trace_path[512], report_path[512];
    snprintf(trace_path, sizeof(trace_path), "%s/triad_trace.csv", outdir);
    snprintf(report_path, sizeof(report_path), "%s/triad_report.json", outdir);

    FILE* csv = fopen(trace_path, "wb");
    if (!csv){
        fprintf(stderr, "FAIL open %s\n", trace_path);
        return 2;
    }

    // CSV header
    fprintf(csv, "n,u,v,c_re,c_im,z_re,z_im,escaped,D_re,D_im,gate_9to1,J_n,stable_any,gate_in_peaks,fr_matches_gate,fp1_stable,fp2_stable,FR,FR_prev,FR_rev\n");

    // PRNG: simple LCG (deterministic low-level)
    unsigned long long rng = (unsigned long long)(p.seed ? p.seed : 1);
    (void)rng; // reserved (not used now, but seed is kept for future stochastic variants)

    long long* FR = fr_build(64);
    if (!FR){ fprintf(stderr,"FAIL fr_build\n"); fclose(csv); return 2; }

    int gate_hist[10] = {0};
    int J_hist[4] = {0};
    int stable_hits = 0;
    int escaped_ct = 0;

    cplx z = {p.z0_re, p.z0_im};

    int last_gate = 0, last_J = 0;
    long long last_FR = 0;

    for (int n=0;n<p.steps;n++){
        double u = (double)n * p.alpha;
        double v = (double)n * p.beta;

        cplx c = torus_c(u, v, &p);

        // Mandelbrot
        cplx zz = c_mul(z, z);
        z = c_add(zz, c);

        int escaped = 0;
        if (!isfinite(z.re) || !isfinite(z.im) || c_abs(z) > p.z_cap){
            escaped = 1;
            escaped_ct++;
            z = (cplx){p.z0_re, p.z0_im};
        }

        // Bhaskara + fixpoints
        cplx z1, z2, D;
        fixpoints_from_c(c, &z1, &z2, &D);
        int st1 = stable_fixpoint(z1);
        int st2 = stable_fixpoint(z2);
        int stable_any = (st1 || st2) ? 1 : 0;
        if (stable_any) stable_hits++;

        // gate = dr9(floor(lam*|Δ|))
        double dmag = c_abs(D);
        long long gsrc = safe_floor_ll(p.lam * dmag);
        int gate = dr9_long(gsrc);
        gate_hist[gate]++;

        int gate_in_peaks = (gate==3 || gate==4 || gate==8) ? 1 : 0;

        // FR window
        int idx = (n % 64) + 1; // 1..64
        long long FRn = FR[idx];
        long long FRnm1 = (idx>1) ? FR[idx-1] : FR[64];
        long long FRrev = fr_rev_step(FRn, FRnm1);

        int fr_matches_gate = (dr9_long(FRn) == gate) ? 1 : 0;

        int Jn = stable_any + gate_in_peaks + fr_matches_gate;
        if (Jn < 0) Jn = 0; if (Jn > 3) Jn = 3;
        J_hist[Jn]++;

        // write row
        fprintf(csv,
            "%d,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%d,%.15g,%.15g,%d,%d,%d,%d,%d,%d,%d,%lld,%lld,%lld\n",
            n,u,v,c.re,c.im,z.re,z.im,escaped,D.re,D.im,gate,Jn,stable_any,gate_in_peaks,fr_matches_gate,st1,st2,FRn,FRnm1,FRrev
        );

        last_gate = gate;
        last_J = Jn;
        last_FR = FRn;
    }

    fclose(csv);
    write_report_json(report_path, &p, stable_hits, escaped_ct, gate_hist, J_hist, last_gate, last_J, last_FR);
    free(FR);

    printf("OK :: TRIAD (C)\n");
    printf("out :: %s\n", trace_path);
    printf("out :: %s\n", report_path);
    printf("stable_hits :: %d/%d\n", stable_hits, p.steps);
    printf("escaped_ct  :: %d\n", escaped_ct);
    printf("gate_hist   :: ");
    for (int i=1;i<=9;i++) printf("%d:%d ", i, gate_hist[i]);
    printf("\n");
    printf("J_hist      :: 0:%d 1:%d 2:%d 3:%d\n", J_hist[0], J_hist[1], J_hist[2], J_hist[3]);
    return 0;
}
