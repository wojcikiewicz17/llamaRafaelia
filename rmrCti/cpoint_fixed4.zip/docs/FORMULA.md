(u_n,v_n)=(u0,v0)+n(α,β)
c_n = κ (R+r cos v_n) e^{i u_n}
z_{n+1} = z_n^2 + c_n

Fixpoint:
z = z^2 + c  => z^2 - z + c = 0
Δ = 1 - 4c
z* = (1 ± √Δ)/2
estável se |2 z*| < 1

9->1:
π_n = dr( floor( λ |Δ| ) )

Fib reversa:
F_{n-2} = F_n - F_{n-1}
