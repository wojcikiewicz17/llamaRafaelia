#!/usr/bin/env sh
set -e

F="$HOME/storage/downloads/conversations.json"
EVENTS="omega_events.jsonl"
OUT="regime.index.jsonl"
CHUNK=$((8*1024*1024))   # 8MB

echo "[OMEGA] arquivo: $F"
ls -lh "$F"

echo "[OMEGA] lendo $EVENTS"
echo "[OMEGA] saída -> $OUT"
: > "$OUT"

# helper: parse omega_neon (multilinha) -> 1 json
emit_json() {
  Z="$1"; OFF="$2"; DPPM="$3"
  awk -v z="$Z" -v off="$OFF" -v dppm="$DPPM" '
    BEGIN{
      bytes=hibit=space=nl=brace=quote=colon=comma=-1
    }
    $1=="BYTES:" {bytes=$2}
    $1=="HIBIT:" {hibit=$2}
    $1=="SPACE:" {space=$2}
    $1=="NL:"    {nl=$2}
    $1=="BRACE:" {brace=$2}
    $1=="QUOTE:" {quote=$2}
    $1=="COLON:" {colon=$2}
    $1=="COMMA:" {comma=$2}
    END{
      # 1 objeto JSON por zona
      printf("{\"zone\":%d,\"off\":%d,\"dppm\":%d,", z, off, dppm);
      printf("\"bytes\":%d,\"hibit\":%d,\"space\":%d,\"nl\":%d,", bytes, hibit, space, nl);
      printf("\"brace\":%d,\"quote\":%d,\"colon\":%d,\"comma\":%d}\n", brace, quote, colon, comma);
    }
  '
}

# percorre apenas os eventos regime
grep '"event":"regime"' "$EVENTS" | while read -r line; do
  ZONE=$(echo "$line" | sed -n 's/.*"zone":\([0-9]*\).*/\1/p')
  OFF=$(echo "$line"  | sed -n 's/.*"off":\([0-9]*\).*/\1/p')
  DPPM=$(echo "$line" | sed -n 's/.*"dppm":\([0-9]*\).*/\1/p')

  echo "[ZONE $ZONE] off=$OFF dppm=$DPPM"

  # slice -> neon -> json (1 linha)
  ./omega_slice2 "$F" "$OFF" "$CHUNK" \
    | ./omega_neon \
    | emit_json "$ZONE" "$OFF" "$DPPM" \
    >> "$OUT"
done

echo "[OMEGA] DONE"
echo "[OMEGA] objetos JSON (zonas regime) = $(wc -l < "$OUT")"
