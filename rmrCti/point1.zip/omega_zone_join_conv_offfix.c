#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192

typedef struct {
    int zone;
    long off, zbytes;
} Zone;

static int get_int(const char*s,const char*k,int*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}
static int get_long(const char*s,const char*k,long*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}

static int cmp(const void*a,const void*b){
    const Zone*x=a,*y=b;
    return (x->off>y->off)-(x->off<y->off);
}

int main(int argc,char**argv){
    if(argc<3){
        fprintf(stderr,"uso: %s zones_index.jsonl omega_msgs.jsonl\n",argv[0]);
        return 1;
    }

    FILE *fz=fopen(argv[1],"r");
    FILE *fm=fopen(argv[2],"r");
    FILE *fo=fopen("omega_zone_conv_map.jsonl","w");
    if(!fz||!fm||!fo){ perror("io"); return 2; }

    size_t zn=0,zc=256;
    Zone *z=malloc(zc*sizeof* z);
    char l[LINE];

    while(fgets(l,LINE,fz)){
        Zone t={0};
        if(!get_int(l,"\"zone\"",&t.zone)) continue;
        if(!get_long(l,"\"off\"",&t.off)) continue;
        if(!get_long(l,"\"zbytes\"",&t.zbytes)) continue;
        if(zn>=zc){ zc<<=1; z=realloc(z,zc*sizeof* z); }
        z[zn++]=t;
    }
    fclose(fz);
    qsort(z,zn,sizeof* z,cmp);

    long rows=0, miss=0;
    while(fgets(l,LINE,fm)){
        int conv; long off;
        if(!get_int(l,"\"conv_i\"",&conv)) continue;
        if(!get_long(l,"\"off\"",&off)) continue;

        size_t lo=0,hi=zn;
        int found=0;
        while(lo<hi){
            size_t m=(lo+hi)>>1;
            long a=z[m].off, b=a+z[m].zbytes;
            if(off>=a && off<b){
                fprintf(fo,"{\"zone\":%d,\"conv_i\":%d,\"off\":%ld}\n",
                        z[m].zone,conv,off);
                rows++; found=1; break;
            }
            if(off<a) hi=m; else lo=m+1;
        }
        if(!found) miss++;
    }

    fclose(fm); fclose(fo); free(z);
    fprintf(stderr,
      "[omega_zone_join_conv_offfix] OK -> omega_zone_conv_map.jsonl  zones=%zu  rows=%ld  miss=%ld\n",
      zn, rows, miss
    );
    return 0;
}
