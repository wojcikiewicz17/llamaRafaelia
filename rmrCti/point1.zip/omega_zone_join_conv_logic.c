#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192
#define ZMAX 136

static int get_int(const char*s,const char*k,int*o){
  const char*p=strstr(s,k); if(!p) return 0;
  p=strchr(p,':'); if(!p) return 0;
  *o=(int)strtol(p+1,NULL,10); return 1;
}

int main(void){
  FILE *fm=fopen("omega_msgs.jsonl","r");
  FILE *fo=fopen("omega_zone_conv_map.logic.jsonl","w");
  if(!fm||!fo){ perror("io"); return 1; }

  char l[LINE];
  long long rows=0;
  while(fgets(l,LINE,fm)){
    int conv;
    if(!get_int(l,"\"conv_i\"",&conv)) continue;
    int zone = (conv % ZMAX + ZMAX) % ZMAX;
    fprintf(fo,"{\"zone\":%d,\"conv_i\":%d}\n",zone,conv);
    rows++;
  }
  fclose(fm); fclose(fo);
  fprintf(stderr,"[omega_zone_join_conv_logic] OK -> omega_zone_conv_map.logic.jsonl rows=%lld\n", rows);
  return 0;
}
