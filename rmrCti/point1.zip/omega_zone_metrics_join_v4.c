#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192
#define ZMAX 4096

typedef struct {
  int seen;
  double IC, PP, CV;
} MRow;

static int get_long(const char*s,const char*k,long*o){
  const char*p=strstr(s,k); if(!p) return 0;
  p=strchr(p,':'); if(!p) return 0;
  char *e=0; long v=strtol(p+1,&e,10);
  if(e==(p+1)) return 0; *o=v; return 1;
}
static int get_int(const char*s,const char*k,int*o){
  long v; if(!get_long(s,k,&v)) return 0; *o=(int)v; return 1;
}
static int get_d(const char*s,const char*k,double*o){
  const char*p=strstr(s,k); if(!p) return 0;
  p=strchr(p,':'); if(!p) return 0;
  char *e=0; double v=strtod(p+1,&e);
  if(e==(p+1)) return 0; *o=v; return 1;
}

int main(void){
  const char *FM="omega_metrics_v3.jsonl";
  const char *FZ="omega_zone_conv_map.jsonl";
  const char *OUTX="zone_x_metrics.txt";
  const char *OUTS="zone_stats.txt";

  FILE *fm=fopen(FM,"r");
  if(!fm){ perror("io metrics"); return 1; }

  // 1) carregar métricas por conv_i
  MRow *m=NULL; size_t mc=0;
  char line[LINE];
  int maxc=-1;

  while(fgets(line,LINE,fm)){
    int c=-1; double ic=0,pp=0,cv=0;
    if(!get_int(line,"\"conv_i\"",&c)) continue;
    get_d(line,"\"IC\"",&ic);
    get_d(line,"\"PP\"",&pp);
    get_d(line,"\"CV\"",&cv);

    if(c>maxc) maxc=c;
    if((size_t)(maxc+1)>mc){
      size_t nmc=(mc?mc:1024);
      while(nmc<(size_t)(maxc+1)) nmc<<=1;
      MRow *nm=(MRow*)realloc(m,nmc*sizeof(MRow));
      if(!nm){ fprintf(stderr,"oom\n"); free(m); return 2; }
      // zero init new tail
      for(size_t i=mc;i<nmc;i++){ nm[i].seen=0; nm[i].IC=0; nm[i].PP=0; nm[i].CV=0; }
      m=nm; mc=nmc;
    }
    m[c].seen=1;
    m[c].IC=ic; m[c].PP=pp; m[c].CV=cv;
  }
  fclose(fm);

  FILE *fz=fopen(FZ,"r");
  if(!fz){ perror("io zone_map"); free(m); return 1; }

  FILE *fx=fopen(OUTX,"w");
  if(!fx){ perror("io out"); fclose(fz); free(m); return 1; }

  // 2) agrega por zona
  long zcnt[ZMAX]; double sic[ZMAX], spp[ZMAX], scv[ZMAX];
  memset(zcnt,0,sizeof(zcnt));
  memset(sic,0,sizeof(sic));
  memset(spp,0,sizeof(spp));
  memset(scv,0,sizeof(scv));

  long rows=0, miss_m=0, bad=0;
  while(fgets(line,LINE,fz)){
    int z=-1,c=-1;
    if(!get_int(line,"\"zone\"",&z)){ bad++; continue; }
    if(!get_int(line,"\"conv_i\"",&c)){ bad++; continue; }
    if(z<0||z>=ZMAX){ bad++; continue; }

    double ic=0,pp=0,cv=0;
    if(c<0 || (size_t)c>=mc || !m[c].seen){
      miss_m++;
    } else {
      ic=m[c].IC; pp=m[c].PP; cv=m[c].CV;
    }

    fprintf(fx,"%d\t%d\t%.6f\t%.6f\t%.6f\n",z,c,ic,pp,cv);

    zcnt[z]++; sic[z]+=ic; spp[z]+=pp; scv[z]+=cv;
    rows++;
  }
  fclose(fz); fclose(fx);

  FILE *fs=fopen(OUTS,"w");
  if(!fs){ perror("io stats"); free(m); return 1; }

  fprintf(fs,"zone\trefs\tIC_mean\tPP_mean\tCV_mean\n");
  for(int z=0; z<ZMAX; z++){
    if(zcnt[z]<=0) continue;
    double den=(double)zcnt[z];
    fprintf(fs,"%d\t%ld\t%.6f\t%.6f\t%.6f\n",
      z, zcnt[z],
      sic[z]/den,
      spp[z]/den,
      scv[z]/den
    );
  }
  fclose(fs);

  free(m);

  fprintf(stderr,
    "[omega_zone_metrics_join_v4] OK -> %s + %s  "
    "rows=%ld  miss_metrics=%ld  bad=%ld\n",
    OUTX, OUTS, rows, miss_m, bad
  );
  return 0;
}
