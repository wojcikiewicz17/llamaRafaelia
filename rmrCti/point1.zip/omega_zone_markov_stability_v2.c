#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192
#define ZMAX 512

static int get_int(const char*s,const char*k,int*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}

int main(int argc,char**argv){
    if(argc<2){ fprintf(stderr,"uso: %s map.jsonl\n",argv[0]); return 1; }
    FILE *f=fopen(argv[1],"r");
    if(!f){ perror("io"); return 2; }

    unsigned long M[ZMAX][ZMAX]={0};
    FILE *fe=fopen("zone_markov_edges.txt","w");
    FILE *fs=fopen("zone_conv_streaks.txt","w");

    char l[LINE]; int last=-1,curr,streak=0; long rows=0;

    while(fgets(l,LINE,f)){
        if(!get_int(l,"\"zone\"",&curr)) continue;
        rows++;
        if(last!=-1){
            if(curr==last) streak++;
            else{
                fprintf(fs,"STREAK\tzone=%d\tlen=%d\n",last,streak);
                if(last<ZMAX&&curr<ZMAX) M[last][curr]++;
                streak=1;
            }
        } else streak=1;
        last=curr;
    }
    if(last!=-1) fprintf(fs,"STREAK\tzone=%d\tlen=%d\n",last,streak);

    for(int i=0;i<ZMAX;i++)
      for(int j=0;j<ZMAX;j++)
        if(M[i][j]) fprintf(fe,"EDGE\t%d->%d\t%lu\n",i,j,M[i][j]);

    fclose(f); fclose(fe); fclose(fs);
    fprintf(stderr,
      "[omega_zone_markov_stability_v2] OK :: in=%s rows=%ld\n",
      argv[1],rows
    );
    return 0;
}
