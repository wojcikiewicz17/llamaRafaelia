#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { int conv_i,total,infra,sec,ai,symb,msgs; } Row;

static int json_get_int(const char *line, const char *key, int *out){
    char pat[80];
    snprintf(pat,sizeof(pat),"\"%s\":",key);
    const char *p=strstr(line,pat); if(!p) return 0;
    p += strlen(pat);
    *out = atoi(p);
    return 1;
}

static int cmp_desc(const void *a, const void *b){
    const Row *x=(const Row*)a, *y=(const Row*)b;
    return (y->total - x->total);
}

int main(int argc,char **argv){
    const char *in = (argc>1)?argv[1]:"omega_value_map.jsonl";
    int topN = (argc>2)?atoi(argv[2]):20;
    if(topN<=0) topN=20;

    FILE *f=fopen(in,"r"); if(!f){ perror(in); return 1; }

    size_t cap=4096, n=0;
    Row *v=(Row*)malloc(cap*sizeof(Row));
    if(!v){ fprintf(stderr,"OOM\n"); return 2; }

    char *line=NULL; size_t lc=0;
    while(getline(&line,&lc,f)!=-1){
        Row r={0,0,0,0,0,0,0};
        if(!json_get_int(line,"conv_i",&r.conv_i)) continue;
        json_get_int(line,"total",&r.total);
        json_get_int(line,"infra",&r.infra);
        json_get_int(line,"security",&r.sec);
        json_get_int(line,"ai",&r.ai);
        json_get_int(line,"symbolic",&r.symb);
        json_get_int(line,"msgs",&r.msgs);

        if(n==cap){
            cap*=2;
            v=(Row*)realloc(v,cap*sizeof(Row));
            if(!v){ fprintf(stderr,"OOM\n"); return 2; }
        }
        v[n++]=r;
    }

    qsort(v,n,sizeof(Row),cmp_desc);

    printf("rank\ttotal\tinfra\tsec\tai\tsymb\tmsgs\tconv_i\n");
    int lim = (topN<(int)n)?topN:(int)n;
    for(int i=0;i<lim;i++){
        Row *r=&v[i];
        printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
            i+1,r->total,r->infra,r->sec,r->ai,r->symb,r->msgs,r->conv_i);
    }

    free(line); free(v); fclose(f);
    return 0;
}
