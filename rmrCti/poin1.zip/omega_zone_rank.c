#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192
#define ZMAX 512

typedef struct { int zone; long cnt; } ZRow;

static int get_int(const char*s,const char*k,int*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}
static int cmp(const void*a,const void*b){
    const ZRow*x=a,*y=b;
    return (y->cnt>x->cnt)-(y->cnt<x->cnt);
}

int main(int argc,char**argv){
    if(argc<2){ fprintf(stderr,"uso: %s map.jsonl [topN]\n",argv[0]); return 1; }
    int topN = argc>2? atoi(argv[2]):30;

    FILE *f=fopen(argv[1],"r");
    if(!f){ perror("io"); return 2; }

    long counts[ZMAX]={0}, rows=0, bad=0;
    int maxz=0; char l[LINE];

    while(fgets(l,LINE,f)){
        int z;
        if(!get_int(l,"\"zone\"",&z)){ bad++; continue; }
        if(z<0||z>=ZMAX){ bad++; continue; }
        counts[z]++; rows++; if(z>maxz) maxz=z;
    }
    fclose(f);

    ZRow *v=malloc((maxz+1)*sizeof* v); int n=0;
    for(int z=0;z<=maxz;z++) if(counts[z]) v[n++] = (ZRow){z,counts[z]};
    qsort(v,n,sizeof* v,cmp);

    printf("rank\tzone\tconv_refs\tshare\n");
    for(int i=0;i<topN && i<n;i++){
        printf("%d\t%d\t%ld\t%.2f%%\n",
            i+1,v[i].zone,v[i].cnt,100.0*v[i].cnt/rows);
    }
    fprintf(stderr,
      "[omega_zone_rank] OK :: in=%s rows=%ld zones=%d bad=%ld\n",
      argv[1],rows,n,bad
    );
    free(v); return 0;
}
