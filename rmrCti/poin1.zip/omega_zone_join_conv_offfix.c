#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192

static int get_int(const char*s,const char*k,int*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}
static int get_long(const char*s,const char*k,long*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}

typedef struct { int zone; long off, zbytes; } Zone;

int cmp(const void*a,const void*b){
    const Zone*x=a,*y=b;
    return (x->off<y->off)?-1:(x->off>y->off);
}

int main(){
    FILE *fz=fopen("omega_zone_metrics.jsonl","r");
    FILE *fm=fopen("omega_msgs.jsonl","r");
    if(!fz||!fm){perror("io");return 1;}

    Zone *z=NULL; size_t zn=0,zc=256;
    z=malloc(zc*sizeof* z);
    char l[LINE];

    while(fgets(l,LINE,fz)){
        Zone t={0};
        if(!get_int(l,"\"zone\"",&t.zone)) continue;
        if(!get_long(l,"\"off\"",&t.off)) continue;
        if(!get_long(l,"\"zbytes\"",&t.zbytes)) continue;
        if(zn>=zc){ zc<<=1; z=realloc(z,zc*sizeof* z); }
        z[zn++]=t;
    }
    fclose(fz);
    if(!zn){ fprintf(stderr,"[offfix] NO zones loaded\n"); return 2; }

    qsort(z,zn,sizeof* z,cmp);

    FILE *fo=fopen("omega_zone_conv_map.tmp","w");
    if(!fo){perror("out");return 3;}

    long rows=0,miss=0;
    while(fgets(l,LINE,fm)){
        int conv; long off;
        if(!get_int(l,"\"conv_i\"",&conv)){ miss++; continue; }
        if(!get_long(l,"\"off\"",&off)){ miss++; continue; }

        size_t lo=0,hi=zn;
        while(lo<hi){
            size_t m=(lo+hi)>>1;
            long a=z[m].off,b=a+z[m].zbytes;
            if(off>=a && off<b){
                fprintf(fo,"{\"zone\":%d,\"conv_i\":%d,\"off\":%ld}\n",
                        z[m].zone,conv,off);
                rows++; break;
            }
            if(off<a) hi=m; else lo=m+1;
        }
    }
    fclose(fm); fclose(fo); free(z);

    if(rows>0){
        rename("omega_zone_conv_map.tmp","omega_zone_conv_map.jsonl");
        fprintf(stderr,
          "[offfix] OK -> omega_zone_conv_map.jsonl zones=%zu rows=%ld miss=%ld\n",
          zn,rows,miss);
    } else {
        remove("omega_zone_conv_map.tmp");
        fprintf(stderr,
          "[offfix] FAIL SAFE: no rows written (miss=%ld)\n",miss);
    }
    return 0;
}
