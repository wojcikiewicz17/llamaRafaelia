#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE 8192
#define MAXC 400000

static int get_int(const char*s,const char*k,int*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtol(p+1,NULL,10); return 1;
}
static int get_d(const char*s,const char*k,double*o){
    const char*p=strstr(s,k); if(!p) return 0;
    p=strchr(p,':'); if(!p) return 0;
    *o=strtod(p+1,NULL); return 1;
}

int main(){
    double IC[MAXC]={0},PP[MAXC]={0},CV[MAXC]={0};
    int seen[MAXC]={0};

    FILE *fm=fopen("omega_metrics_v3.jsonl","r");
    if(!fm){perror("metrics");return 1;}
    char l[LINE]; int c; double d;
    while(fgets(l,LINE,fm)){
        if(!get_int(l,"\"conv_i\"",&c)) continue;
        if(get_d(l,"\"IC\"",&d)) IC[c]=d;
        if(get_d(l,"\"PP\"",&d)) PP[c]=d;
        if(get_d(l,"\"CV\"",&d)) CV[c]=d;
        seen[c]=1;
    }
    fclose(fm);

    FILE *fz=fopen("omega_zone_conv_map.jsonl","r");
    FILE *fo=fopen("zone_x_metrics.txt","w");
    if(!fz||!fo){perror("join");return 2;}

    long rows=0,miss=0;
    while(fgets(l,LINE,fz)){
        int z;
        if(!get_int(l,"\"zone\"",&z)) continue;
        if(!get_int(l,"\"conv_i\"",&c)) continue;
        if(!seen[c]){ miss++; continue; }
        fprintf(fo,"%d\t%d\t%.6f\t%.6f\t%.6f\n",
                z,c,IC[c],PP[c],CV[c]);
        rows++;
    }
    fclose(fz); fclose(fo);

    fprintf(stderr,
      "[metrics_join] OK -> zone_x_metrics.txt rows=%ld miss_metrics=%ld\n",
      rows,miss);
    return 0;
}
