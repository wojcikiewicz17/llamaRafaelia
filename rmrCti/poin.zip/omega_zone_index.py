#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, sys, math, time

CHUNK = 8 * 1024 * 1024   # 8MB
STEP  = 8 * 1024 * 1024
MAX   = 1 << 40          # sem limite prático

def shannon(bs):
    freq = [0]*256
    for b in bs:
        freq[b] += 1
    n = len(bs)
    ent = 0.0
    for c in freq:
        if c:
            p = c/n
            ent -= p * math.log2(p)
    return ent

def classify(ent, ratio):
    if ent < 4.5 and ratio < 0.48:
        return "STRUCT_JSON"
    if 4.5 <= ent <= 6.0 and 0.45 <= ratio <= 0.55:
        return "TEXT_HUMAN"
    if ent > 6.2 or ratio > 0.6 or ratio < 0.4:
        return "NOISE_BIN"
    return "MIXED"

def human(n):
    for u in ["B","KB","MB","GB","TB"]:
        if n < 1024:
            return f"{n:.2f}{u}"
        n /= 1024
    return f"{n:.2f}PB"

def main():
    if len(sys.argv) < 2:
        print("uso: omega_zone_index.py <arquivo>", file=sys.stderr)
        sys.exit(1)

    path = sys.argv[1]
    size = os.path.getsize(path)

    print("# zone off bytes ones_ratio entropy class")
    sys.stderr.write(f"[OMEGA] scanning {path}\n")
    sys.stderr.write(f"[OMEGA] size = {human(size)} | chunk = {human(CHUNK)}\n")

    with open(path, "rb") as f:
        zone = 0
        off  = 0
        prev_ent = None
        t0 = time.time()

        while off < size and off < MAX:
            f.seek(off)
            data = f.read(CHUNK)
            if not data:
                break

            ones = sum(bin(b).count("1") for b in data)
            ratio = ones / (len(data) * 8)
            ent = shannon(data)
            cls = classify(ent, ratio)

            if prev_ent is not None and abs(ent - prev_ent) > 0.8:
                print(f"!! FRONTIER @ {off}")

            print(f"{zone:04d} {off:12d} {len(data):8d} {ratio:0.4f} {ent:0.3f} {cls}")

            # ---- status vivo ----
            pct = (off / size) * 100
            elapsed = time.time() - t0
            speed = off / elapsed if elapsed > 0 else 0

            sys.stderr.write(
                f"\r[ZONE {zone:4d}] "
                f"{pct:6.2f}% "
                f"{human(off)}/{human(size)} "
                f"speed={human(speed)}/s "
                f"ent={ent:0.2f} "
                f"class={cls}        "
            )
            sys.stderr.flush()

            prev_ent = ent
            off  += STEP
            zone += 1

    sys.stderr.write("\n[OMEGA] done.\n")

if __name__ == "__main__":
    main()
