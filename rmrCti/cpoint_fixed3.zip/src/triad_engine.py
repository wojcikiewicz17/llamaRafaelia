# --- compat: legacy alias ---

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TRIAD_ENGINE
Toroide -> c_n -> Mandelbrot
Bhaskara Δ no fixpoint: z=z^2+c => z^2 - z + c = 0 => Δ = 1 - 4c
9->1 via digital root
Fibonacci forward + reverse (F_{n-2} = F_n - F_{n-1})
stdlib only
"""
# --- compat: FRn alias ---


import argparse
import json
import math
import csv
import os
import random
from dataclasses import dataclass, asdict

# --- RAFAELIA compat: FR fallback ---
def FR(n: int) -> int:
    """
    Fallback estável (determinístico) para FR.
    Se você tiver uma RafaFibo específica, pode substituir aqui.
    Por padrão: Fibonacci clássico (0,1,1,2,3,...)
    """
    n = int(n)
    if n <= 0:
        return 0
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

def dr9(x: int) -> int:
    """digital root in 1..9; 0 maps to 9"""
    x = abs(int(x))
    if x == 0:
        return 9
    r = x % 9
    return 9 if r == 0 else r

def fib_seq(n: int):
    """returns list [F0..Fn]"""
    if n <= 0:
        return [0]
    f = [0, 1]
    for _ in range(2, n + 1):
        f.append(f[-1] + f[-2])
    return f

def fib_rev_step(Fn: int, Fnm1: int):
    """reverse: F_{n-2} = F_n - F_{n-1}"""
    return Fn - Fnm1

@dataclass
class Params:
    steps: int = 300
    seed: int = 42
    R: float = 2.0
    r: float = 0.7
    alpha: float = math.pi / 7.0
    beta: float  = math.pi / 9.0
    kappa: float = 0.22
    z0_re: float = 0.0
    z0_im: float = 0.0
    lam: float = 1000.0
    z_cap: float = 1e6  # overflow clamp

def fr_seq(n: int):
    """Fibonacci-Rafael Fᴿ:
       F1=2, F2=4, F_n = F_{n-1} + F_{n-2} - 1
       retorna lista indexada em 1..n (posição 0 = 0 placeholder)
    """
    if n <= 0:
        return [0]
    if n == 1:
        return [0, 2]
    f = [0, 2, 4]
    for _ in range(3, n + 1):
        f.append(f[-1] + f[-2] - 1)
    return f

def fr_rev_step(Fn: int, Fnm1: int):
    """reverse FR: F_{n-2} = F_n - F_{n-1} + 1"""
    return Fn - Fnm1 + 1


def torus_c(u: float, v: float, p: Params) -> complex:
    s = (p.R + p.r * math.cos(v))
    x = s * math.cos(u)
    y = s * math.sin(u)
    return p.kappa * complex(x, y)

def bhaskara_delta(c: complex) -> complex:
    return 1.0 - 4.0 * c

def complex_sqrt(z: complex) -> complex:
    r = abs(z)
    if r == 0:
        return 0j
    a = z.real
    b = z.imag
    t = math.sqrt((r + a) / 2.0)
    u = math.sqrt((r - a) / 2.0)
    if b < 0:
        u = -u
    return complex(t, u)

def fixpoints_from_c(c: complex):
    D = bhaskara_delta(c)
    s = complex_sqrt(D)
    z1 = (1.0 + s) / 2.0
    z2 = (1.0 - s) / 2.0
    return z1, z2, D

def stable_fixpoint(z_fp: complex) -> bool:
    return abs(2.0 * z_fp) < 1.0

def run(p: Params, out_dir: str):
        random.seed(p.seed)

        u0 = 0.0
        v0 = 0.0




        z = complex(p.z0_re, p.z0_im)
        FR = fr_seq(24)

        trace_path = os.path.join(out_dir, "triad_trace.csv")
        report_path = os.path.join(out_dir, "triad_report.json")

        rows = []
        stable_ct = 0
        gate_hist = [0] * 10  # 0..9 (we use 1..9)
        J_hist = [0] * 4      # 0..3
        peaks = {3, 4, 8}

        for n in range(p.steps):
            u = u0 + n * p.alpha
            v = v0 + n * p.beta

            c = torus_c(u, v, p)
            z = z * z + c

            escaped = 0
            if (not math.isfinite(z.real)) or (not math.isfinite(z.imag)) or abs(z) > p.z_cap:
                escaped = 1
                z = complex(p.z0_re, p.z0_im)
            z1, z2, D = fixpoints_from_c(c)
            st1 = stable_fixpoint(z1)
            st2 = stable_fixpoint(z2)
            if st1 or st2:
                stable_ct += 1

            gate = dr9(int(p.lam * abs(D)))
            gate_hist[gate] += 1

            stable_any = 1 if (st1 or st2) else 0
            gate_in_peaks = 1 if (gate in peaks) else 0
            fr_matches_gate = 1 if (dr9(Fn) == gate) else 0
            J_n = stable_any + gate_in_peaks + fr_matches_gate
            J_hist[J_n] += 1
            # Fibonacci-Rafael window (bounded)
            # FR is 1-indexed (FR[0]=0 placeholder)
            idx = (n % (len(FR)-1)) + 1
            Fn = FR[idx]
            Fnm1 = FR[idx - 1] if idx > 1 else FR[-1]
            Frev = fr_rev_step(Fn, Fnm1)

            rows.append({
                "n": n,
                "u": u,
                "v": v,
                "c_re": c.real,
                "c_im": c.imag,
                "z_re": z.real,
                "z_im": z.imag,
                "escaped": int(escaped),
                "D_re": D.real,
                "D_im": D.imag,
                "gate_9to1": gate,
                "J_n": int(J_n),
                "stable_any": int(stable_any),
                "gate_in_peaks": int(gate_in_peaks),
                "fr_matches_gate": int(fr_matches_gate),
                "fp1_stable": int(st1),
                "fp2_stable": int(st2),
                "FR": Fn,
                "FR_prev": Fnm1,
                "FR_rev": Frev,
            })

        with open(trace_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

        rep = {
            "params": asdict(p),
            "steps": p.steps,
            "stable_fixpoint_hits": stable_ct,
            "gate_hist_1to9": {str(i): gate_hist[i] for i in range(1, 10)},
        "J_hist_0to3": {str(i): J_hist[i] for i in range(0, 4)},
        "J_peaks": [3,4,8],
            "last": rows[-1],
        "escaped_last": int(rows[-1].get("escaped", 0)),
            "notes": {
                "triad": (
                    "Toroide->c_n ; Mandelbrot z^2+c ; "
                    "Bhaskara Δ=1-4c ; 9->1=dr(|Δ|) ; "
                    "Fib reverse F_{n-2}=F_n-F_{n-1}"
                )
            }
        }
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(rep, f, ensure_ascii=False, indent=2)

        print("OK :: TRIAD_ENGINE")
        print("out ::", trace_path)
        print("out ::", report_path)
        print(f"stable_hits :: {stable_ct}/{p.steps}")
        print("gate_hist ::", " ".join(f"{i}:{gate_hist[i]}" for i in range(1, 10)))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--R", type=float, default=2.0)
    ap.add_argument("--r", type=float, default=0.7)
    ap.add_argument("--alpha", type=float, default=math.pi/7.0)
    ap.add_argument("--beta", type=float, default=math.pi/9.0)
    ap.add_argument("--kappa", type=float, default=0.22)
    ap.add_argument("--lam", type=float, default=1000.0)
    ap.add_argument("--out", type=str, default="out")
    args = ap.parse_args()

    p = Params(
        steps=args.steps,
        seed=args.seed,
        R=args.R,
        r=args.r,
        alpha=args.alpha,
        beta=args.beta,
        kappa=args.kappa,
        lam=args.lam,
    )

    out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", args.out))
    os.makedirs(out_dir, exist_ok=True)
    run(p, out_dir)

if __name__ == "__main__":
    main()

# --- compat: legacy alias ---
