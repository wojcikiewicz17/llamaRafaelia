// rafa_cti_scan.c
// RAFAELIA CTI :: streaming audit (no decompress)
// chunk=4096B, FID=CRC32C, Energy(E) on 256x128 bit-grid, Flip(F), Entropy(H), BadEvent(X)
// Output: JSONL append-only "bitstack"

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>

#ifndef CHUNK_BYTES
#define CHUNK_BYTES 4096
#endif

// Bit-grid for energy: 32768 bits = 4096 bytes * 8
#define GRID_W 256
#define GRID_H 128
#define GRID_BITS (GRID_W * GRID_H)

_Static_assert(GRID_BITS == CHUNK_BYTES * 8, "GRID must match chunk bits");

// ---------------- CRC32C (Castagnoli) ----------------
// Polynomial (reversed): 0x82F63B78
static uint32_t crc32c_table[256];

static void crc32c_init(void) {
  const uint32_t poly = 0x82F63B78u;
  for (uint32_t i = 0; i < 256; i++) {
    uint32_t c = i;
    for (int k = 0; k < 8; k++) {
      c = (c & 1) ? (poly ^ (c >> 1)) : (c >> 1);
    }
    crc32c_table[i] = c;
  }
}

static uint32_t crc32c_update(uint32_t crc, const uint8_t *buf, size_t len) {
  crc = ~crc;
  for (size_t i = 0; i < len; i++) {
    crc = crc32c_table[(crc ^ buf[i]) & 0xFFu] ^ (crc >> 8);
  }
  return ~crc;
}

// ---------------- bit helpers ----------------
static inline uint32_t getbit_u8(const uint8_t *bytes, uint32_t bit_index) {
  // MSB-first per byte (deterministic)
  uint32_t byte_i = bit_index >> 3;
  uint32_t bit_in = 7u - (bit_index & 7u);
  return (bytes[byte_i] >> bit_in) & 1u;
}

static inline uint64_t popcount_u64(uint64_t x) {
  return (uint64_t)__builtin_popcountll(x);
}

// ---------------- metrics ----------------
static uint64_t count_ones_bits(const uint8_t *buf, size_t n) {
  // n expected CHUNK_BYTES
  uint64_t ones = 0;
  const uint64_t *p = (const uint64_t *)buf;
  size_t qwords = n / 8;
  for (size_t i = 0; i < qwords; i++) ones += popcount_u64(p[i]);
  for (size_t i = qwords * 8; i < n; i++) ones += popcount_u64((uint64_t)buf[i]);
  return ones;
}

static uint64_t flip_rate_bits(const uint8_t *prev, const uint8_t *cur, size_t n) {
  // Hamming distance (bit flips)
  uint64_t flips = 0;
  const uint64_t *a = (const uint64_t *)prev;
  const uint64_t *b = (const uint64_t *)cur;
  size_t qwords = n / 8;
  for (size_t i = 0; i < qwords; i++) flips += popcount_u64(a[i] ^ b[i]);
  for (size_t i = qwords * 8; i < n; i++) flips += popcount_u64((uint64_t)(prev[i] ^ cur[i]));
  return flips;
}

static uint64_t energy_mismatch_4n(const uint8_t *buf) {
  // Energy = mismatches with right + down neighbors (covers 4-neighborhood symmetry)
  // E counts edges where adjacent bits disagree.
  uint64_t E = 0;

  // Right neighbors
  for (uint32_t y = 0; y < GRID_H; y++) {
    uint32_t row_base = y * GRID_W;
    for (uint32_t x = 0; x + 1 < GRID_W; x++) {
      uint32_t i = row_base + x;
      uint32_t a = getbit_u8(buf, i);
      uint32_t b = getbit_u8(buf, i + 1);
      E += (a ^ b);
    }
  }

  // Down neighbors
  for (uint32_t y = 0; y + 1 < GRID_H; y++) {
    uint32_t row_base = y * GRID_W;
    uint32_t next_base = (y + 1) * GRID_W;
    for (uint32_t x = 0; x < GRID_W; x++) {
      uint32_t i = row_base + x;
      uint32_t a = getbit_u8(buf, i);
      uint32_t b = getbit_u8(buf, next_base + x);
      E += (a ^ b);
    }
  }

  return E;
}

// ---------------- jsonl writer ----------------
static void json_escape_write(FILE *out, const char *s) {
  // minimal escape for filenames if needed (unused here)
  while (*s) {
    unsigned char c = (unsigned char)*s++;
    if (c == '\\' || c == '"') { fputc('\\', out); fputc(c, out); }
    else if (c == '\n') fputs("\\n", out);
    else if (c == '\r') fputs("\\r", out);
    else if (c == '\t') fputs("\\t", out);
    else fputc(c, out);
  }
}

int main(int argc, char **argv) {
  if (argc < 3) {
    fprintf(stderr, "Usage: %s <input_file> <out_bitstack.jsonl>\n", argv[0]);
    return 2;
  }

  const char *in_path = argv[1];
  const char *out_path = argv[2];

  FILE *in = fopen(in_path, "rb");
  if (!in) {
    fprintf(stderr, "ERR open input: %s (%s)\n", in_path, strerror(errno));
    return 1;
  }

  FILE *out = fopen(out_path, "ab"); // append-only
  if (!out) {
    fprintf(stderr, "ERR open output: %s (%s)\n", out_path, strerror(errno));
    fclose(in);
    return 1;
  }

  crc32c_init();

  uint8_t *buf = (uint8_t *)malloc(CHUNK_BYTES);
  uint8_t *prev = (uint8_t *)malloc(CHUNK_BYTES);
  if (!buf || !prev) {
    fprintf(stderr, "ERR malloc\n");
    fclose(in); fclose(out);
    free(buf); free(prev);
    return 1;
  }
  memset(prev, 0, CHUNK_BYTES);

  uint64_t offset = 0;
  uint64_t idx = 0;
  int have_prev = 0;

  while (1) {
    size_t n = fread(buf, 1, CHUNK_BYTES, in);
    int bad = 0;

    if (n == 0) {
      if (feof(in)) break;
      fprintf(stderr, "ERR read at offset=%llu (%s)\n",
              (unsigned long long)offset, strerror(errno));
      bad = 1;
      // stop hard on read error
      break;
    }

    if (n < CHUNK_BYTES) {
      // short read = bad-event flag (but still process as "event")
      bad = 1;
      // pad deterministically with zeros so metrics stay well-defined
      memset(buf + n, 0, CHUNK_BYTES - n);
    }

    uint32_t fid = crc32c_update(0, buf, CHUNK_BYTES);
    uint64_t ones = count_ones_bits(buf, CHUNK_BYTES);
    double entropy_density = (double)ones / (double)(CHUNK_BYTES * 8ull);

    uint64_t flips = have_prev ? flip_rate_bits(prev, buf, CHUNK_BYTES) : 0;
    uint64_t E = energy_mismatch_4n(buf);

    // timestamp (unix)
    time_t ts = time(NULL);

    // JSONL record
    // Fields: idx, off, size, ts, fid_crc32c, E, flips, ones, H, bad
    fprintf(out,
            "{\"idx\":%llu,"
            "\"off\":%llu,"
            "\"size\":%u,"
            "\"ts\":%lld,"
            "\"fid_crc32c\":\"%08x\","
            "\"E\":%llu,"
            "\"F\":%llu,"
            "\"ones\":%llu,"
            "\"H\":%.6f,"
            "\"X_bad\":%d}\n",
            (unsigned long long)idx,
            (unsigned long long)offset,
            (unsigned)CHUNK_BYTES,
            (long long)ts,
            (unsigned)fid,
            (unsigned long long)E,
            (unsigned long long)flips,
            (unsigned long long)ones,
            entropy_density,
            bad);

    // advance
    memcpy(prev, buf, CHUNK_BYTES);
    have_prev = 1;
    offset += (uint64_t)n; // advance by real bytes read (not padded)
    idx++;

    // if it was short read, it was EOF tail: stop after record
    if (n < CHUNK_BYTES) break;
  }

  fflush(out);
  fclose(in);
  fclose(out);
  free(buf);
  free(prev);

  return 0;
}
